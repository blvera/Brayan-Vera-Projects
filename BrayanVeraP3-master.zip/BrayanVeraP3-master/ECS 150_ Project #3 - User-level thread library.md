# ECS 150: Project #3 - User-level thread library (part 2)

## REPORT

### Part 1: semaphore API
The semaphore 

We implemented this by programming function by function from top to bottom. This means that we started programming with the "struct semaphore" where we initialize our waiting Queue and Count. These two are essentila to keep track of the different semaphores we can have. Next, our "sem_create function" is in charge of creating multiple semaphores with the limit of

----TODO more



###### Resources used in phase 1:
* 

### Part 2: TPS API

----TODO

###### Resources used in phase 2:
* http://man7.org/linux/man-pages//man2/munmap.2.html -> Used for knowing what to put inside mmap.(to understand map better)
* https://linux.die.net/man/2/mprotect   --> used to understand the read and write functions better (was provided in the instructions).


